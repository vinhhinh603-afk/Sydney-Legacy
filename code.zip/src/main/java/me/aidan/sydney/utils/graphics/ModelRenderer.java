package me.aidan.sydney.utils.graphics;

import me.aidan.sydney.utils.IMinecraft;
import net.minecraft.entity.Entity;

import java.awt.*;

public class ModelRenderer implements IMinecraft {
    public static void renderModel(Entity entity, float scale, float tickDelta, Render render) {
        renderModel(entity, false, scale, tickDelta, render);
    }

    public static void renderModel(Entity entity, boolean staticEntity, float scale, float tickDelta, Render render) {
    }

    public record Render(boolean fill, Color fillColor, boolean outline, Color outlineColor, boolean shine) { }
}