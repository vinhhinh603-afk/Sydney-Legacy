package me.aidan.sydney.managers;

import lombok.Getter;
import me.aidan.sydney.utils.IMinecraft;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.BufferAllocator;

import java.awt.*;

@Getter
public class ShaderManager implements IMinecraft {
    private final VertexConsumerProvider.Immediate vertexConsumerProvider = VertexConsumerProvider.immediate(new BufferAllocator(256));
    private final Framebuffer framebuffer;

    public ShaderManager() {
        framebuffer = new SimpleFramebuffer(mc.getWindow().getFramebufferWidth(), mc.getWindow().getFramebufferHeight(), true, false);
        framebuffer.setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    }

    public void prepare() {
        framebuffer.setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        framebuffer.clear(true);
        mc.getFramebuffer().beginWrite(false);
    }

    public void render(int renderMode, float opacity) {
        mc.getFramebuffer().beginWrite(false);
    }

    public void resize(int width, int height) {
        if (framebuffer != null) framebuffer.resize(width, height, true);
    }

    public VertexConsumerProvider create(VertexConsumerProvider parent, Color color) {
        return parent;
    }
}
