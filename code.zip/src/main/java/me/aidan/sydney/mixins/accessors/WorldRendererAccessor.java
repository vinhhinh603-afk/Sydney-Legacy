package me.aidan.sydney.mixins.accessors;

import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(WorldRenderer.class)
public interface WorldRendererAccessor {
    @Invoker("getEntityOutlinesFramebuffer")
    Framebuffer getEntityOutlinesFramebuffer();
}
